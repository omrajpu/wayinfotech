<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Profile_update_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
       $this->load->model('Checkout_model');
	}
	function index_get() {

       //rint_r($_GET);die;

       $user_id=$_GET['user_id'];
       //$Username=$_GET['Username'];
       $email=$_GET['email'];
       $contact=$_GET['contact'];
       $fname=$_GET['fname'];
       $lname=$_GET['lname'];
       $gender=$_GET['gender'];
       $created_date=date('Y-m-d H:i:s');
            $update_data=array(
                    'fname'=>$fname,
                    'lname'=>$lname,
                    'email'=>$email,
                    'gender'=>$gender,
                    'mobile'=>$contact,
                    'modify_dt_tm'=>$created_date
                   );
               //print_r($update_data);die;
      $this->Checkout_model->update_customer_data($user_id,$update_data);
      $data_cnt=count($update_data);
      if($data_cnt>0){
          //print_r($service_data);
          $msg=array('msg'=>'User details','status'=>1,'user_data'=>$update_data);
            $this->response($msg); 
          }else{
          $msg=array('msg'=>'User details','status'=>0,'user_data'=>'');
           $this->response($msg);  
          } 
    //   //echo $this->db->last_query();
    // }
    }



    
}


