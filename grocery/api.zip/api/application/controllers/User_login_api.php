<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class User_login_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->model('Checkout_model');
    $this->load->database();
  }
  function index_post(){ 
                       //$data = json_decode(file_get_contents('php://input'));
                       //echo $email=$data->email;
                       // die;
                       // $password=$data->password;
                       // print_r($data);
                      //echo  $email=$this->post('email');
                      //echo   $password=$this->post('password');
                      $email=$_POST['email'];
                      $password= md5(@$_POST['password']);
                     
                      //print_r($_POST);die;
                
                     $check_reg_user = $this->Checkout_model->check_reg_user($email);
                     //print_r($check_reg_user);
                  
                    if(@$check_reg_user->email!=''){
                     $result = $this->Checkout_model->login($email,$password);
                    //print_r($result);
                    $result -> num_rows();
                    
                    if($result -> num_rows() > 0)
                       { 
                       foreach ($result->result() as $row)
                          { 
                            $user_id = $row->id;
                            //$this->session->admin = $row->is_Admin;
                            $email=  $row->email;
                            $mobile=  $row->mobile;
                            $user_name=  $row->fname;
                            $lname=  $row->lname;
                            $file_name=$row->photo;
                            $msg=array('msg'=>'Successfully Login','status'=>'1','user_mobile'=>$mobile,'user_email'=>$email,'user_id'=>$user_id,'fname'=>$user_name,'lname'=>$lname,'image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin/api/profile_pic/','image'=>$file_name);
                            $this->response($msg,200); 
                            
                           }
                        }
                    else
                        {
                        //echo"3"; die;
                         $msg=array('msg'=>'Your Login Details Does Not Match','status'=>'0','login_details'=>'');
                         $this->response($msg);
                       }

                   }else{

                     $msg=array('msg'=>'Your email id does not exist please register now!','status'=>'0','login_details'=>'');
                     $this->response($msg);
                     }
    
  }
  
  
  
}