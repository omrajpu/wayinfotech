<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Product_details_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_get(){ 
      
      //print_r($_GET);die;
    if(@$_GET['vid']){
       
      $pid=$_GET['product_id'];
      $ar=explode('&',$_GET['vid']);
      $sk=array();
      foreach($ar as $key=>$val){
          $ary=explode('=',$val);
          $sk[$ary[0]]=$ary[1];
        }
    //print_r($sk);die;
     
    $this->db->select("*");
    $this->db->from('fp_products');
    $this->db->where('fp_products.id',$pid);
    $query=$this->db->get();
    $result_data=$query->row();
    $vArr = explode("_",$result_data->variants);
   // print_r($vArr);die;
    $cnt=count($vArr);
    $strArr=array(); $str="";
    for($i=0;$i<$cnt;$i++){
   //echo @$sk['p'.$vArr[$i]];
      if(!empty(@$sk['p'.$vArr[$i]])){
        $strArr[] = @$sk['p'.$vArr[$i]];
        $str.="&v".$vArr[$i]."=".@$sk['p'.$vArr[$i]];
        $pvid = @$sk['p'.$vArr[$i]];
       }else{
        $strArr[] =@$sk['v'.$vArr[$i]];
        $str.="&v".$vArr[$i]."=".@$sk['v'.$vArr[$i]];
        } 
    }
  
 //$pvid;
   $likeval= "_".implode("_",$strArr)."_"; 
   //$valArr=implode("_",$strArr); 
   	//$likeval='_27_34_40_';
   //echo "SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'";
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
     $row=$query->num_rows();
     if($row>0){
       $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
       $pvs_row=$query->row();
       $kid=$pvs_row->id;
       $variants_val=$pvs_row->variants_val;
       //$this->get_product_details($pid,$kid,$variants_val);
    $valArr = explode("_",ltrim(rtrim($variants_val,"_"),"_"));
    $this->db->select("fp_products.*,fp_product_variant_sku.id as id,fp_product_variant_sku.pid,fp_product_variant_sku.dpath,fp_product_variant_sku.price,fp_product_desc.highlight,fp_product_desc.content");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
     $this->db->join('fp_product_desc','fp_product_desc.pid=fp_products.id');
    $this->db->where('fp_products.id',$pid);
    $this->db->where('fp_product_variant_sku.id',$kid);
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
    $result_data=$query->result();
    $data=array();
    
    $data['compare_flag'] = 0;
    $cquery = $this->db->query("SELECT * FROM `fp_compare_products` WHERE pid='$pid'");
    $row1= $cquery->num_rows();
    $cquery2 = $this->db->query("SELECT * FROM `fp_compare_products` WHERE cid='$pid'");
    $row2= $cquery2->num_rows();
    if($row1>0 || $row2>0){
        $data['compare_flag'] = 1;
        if($row1>0){
            $query = $this->db->query("SELECT * FROM fp_compare_products WHERE pid='$pid' limit 0,1");
            $prow=$query->row();
            $data['cid'] = $prow->cid;
            $data['pid'] = $pid;
        }
        if($row2>0){
            $query = $this->db->query("SELECT * FROM fp_compare_products WHERE cid='$pid' limit 0,1");
            $prow=$query->row();
            $data['cid'] = $prow->pid;
            $data['pid'] = $pid;
        }
     }
     $spacification=array();
     $query = $this->db->query("SELECT * FROM `fp_product_addinfo` WHERE pid='$pid'");
     $spacification= $query->result();
   // print_r($data);die;
    $variants=$result_data[0]->variants;
    $str="";
        $vArr = explode("_",$variants);
        for($j=0;$j<count($vArr);$j++){
          if($j!=(count($vArr)-1)){
            $str.="v".@$vArr[$j]."=".@$valArr[$j]."&";
          }else{
            $str.="v".@$vArr[$j]."=".@$valArr[$j];
          }
        }
    $i=0;
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid'");
    $krows= $query->result();
    $vvalArr = array(); 
    foreach($krows as $kkey=>$kval){
      $vvalArr[] = explode("_",ltrim(rtrim($kval->variants_val,"_"),"_"));
    }

   $vvalsArr = array(); 
    foreach($vvalArr as $key=>$val){
      for($i=0;$i<count($val);$i++){
        if(!in_array($val[$i],$vvalsArr)){
          array_push($vvalsArr,$val[$i]);
        }
      }
    }
 $vins = "'".str_replace(",","','",implode(",",$vvalsArr))."'"; 
  // echo'<pre>';print_r($vins);die;
$i=0;   
foreach($result_data as $value){
                      //echo $varint_id=$value->variants;
                      $ins = "'".str_replace("_","','",$value->variants)."'";
                      $result_data[$i]->VairantName = $this->getVairantName($ins,$value->pid,$vins,$str,$valArr);
                      $i++;
    }
   //die;
    $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Product data details','status'=>1,'spacification'=>$spacification,'compare_data'=>$data,'Product_data'=>$result_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Product data Not found','status'=>0,'Product_data'=>'');
           $this->response($msg);  
          } 

     }else{
         
      $str="";
      $likeval="_".$pvid."_";
      $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
	  $pvs_row=$query->row();
	  $nvalArr = explode("_",ltrim(rtrim($pvs_row->variants_val,"_"),"_"));
	  $likeval=$pvs_row->variants_val;
	  for($i=0;$i<count($vArr);$i++){
    			$str.="&v".@$vArr[$i]."=".@$nvalArr[$i];	
          }
	  $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
	  $vrow=$query->row();
	  
	   $kid=$vrow->id;
       $variants_val=$vrow->variants_val;
       //$this->get_product_details($pid,$kid,$variants_val);
    $valArr = explode("_",ltrim(rtrim($variants_val,"_"),"_"));
    $this->db->select("fp_products.*,fp_product_variant_sku.id as id,,fp_product_variant_sku.price,fp_product_variant_sku.pid,fp_product_variant_sku.dpath,fp_product_desc.highlight,fp_product_desc.content");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
     $this->db->join('fp_product_desc','fp_product_desc.pid=fp_products.id');
    $this->db->where('fp_products.id',$pid);
    $this->db->where('fp_product_variant_sku.id',$kid);
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
    $result_data=$query->result();
    $data=array();
    $data['compare_flag'] = 0;
    $cquery = $this->db->query("SELECT * FROM `fp_compare_products` WHERE pid='$pid'");
    $row1= $cquery->num_rows();
   
    $cquery2 = $this->db->query("SELECT * FROM `fp_compare_products` WHERE cid='$pid'");
    $row2= $cquery2->num_rows();
    if($row1>0 || $row2>0){
        $data['compare_flag'] = 1;
        if($row1>0){
            $query = $this->db->query("SELECT * FROM fp_compare_products WHERE pid='$pid' limit 0,1");
            $prow=$query->row();
            $data['cid'] = $prow->cid;
            $data['pid'] = $pid;
        }
        if($row2>0){
            $query = $this->db->query("SELECT * FROM fp_compare_products WHERE cid='$pid' limit 0,1");
            $prow=$query->row();
            $data['cid'] = $prow->pid;
            $data['pid'] = $pid;
        }
    }
    $variants=$result_data[0]->variants;
    $str="";
        $vArr = explode("_",$variants);
        for($j=0;$j<count($vArr);$j++){
          if($j!=(count($vArr)-1)){
            $str.="v".@$vArr[$j]."=".@$valArr[$j]."&";
          }else{
            $str.="v".@$vArr[$j]."=".@$valArr[$j];
          }
        }
    $i=0;
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid'");
    $krows= $query->result();
    $vvalArr = array(); 
    foreach($krows as $kkey=>$kval){
      $vvalArr[] = explode("_",ltrim(rtrim($kval->variants_val,"_"),"_"));
    }

   $vvalsArr = array(); 
    foreach($vvalArr as $key=>$val){
      for($i=0;$i<count($val);$i++){
        if(!in_array($val[$i],$vvalsArr)){
          array_push($vvalsArr,$val[$i]);
        }
      }
    }
   $vins = "'".str_replace(",","','",implode(",",$vvalsArr))."'"; 
  // echo'<pre>';print_r($vins);die;
$i=0;   
foreach($result_data as $value) {
                      //echo $varint_id=$value->variants;
                      $ins = "'".str_replace("_","','",$value->variants)."'";
                      $result_data[$i]->VairantName = $this->getVairantName($ins,$value->pid,$vins,$str,$valArr);
                      $i++;
    }
   //die;
    $spacification=array();
    $query = $this->db->query("SELECT * FROM `fp_product_addinfo` WHERE pid='$pid'");
    $spacification= $query->result();
    $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Product data details','status'=>1,'spacification'=>$spacification,'compare_data'=>$data,'Product_data'=>$result_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Product data Not found','status'=>0,'Product_data'=>'');
           $this->response($msg);  
          } 
	  
	  }

   }else{
      // print_r($_GET);die;
    $pid=$_GET['product_id'];
    $kid=$_GET['id'];
    $variants_val=$_GET['variants_val'];
    $valArr = explode("_",ltrim(rtrim($variants_val,"_"),"_"));
    //print_r($valArr);die;
    $this->db->select("fp_products.*,fp_product_variant_sku.id as id,fp_product_variant_sku.pid,fp_product_variant_sku.price,fp_product_variant_sku.dpath,fp_product_desc.highlight,fp_product_desc.content");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
     $this->db->join('fp_product_desc','fp_product_desc.pid=fp_products.id');
    $this->db->where('fp_products.id',$pid);
    $this->db->where('fp_product_variant_sku.id',$kid);
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
   //echo $this->db->last_query();die;
    $result_data=$query->result();
    $data['compare_flag'] = 0;
    $cquery = $this->db->query("SELECT * FROM `fp_compare_products` WHERE pid='$pid'");
    $row1= $cquery->num_rows();
    $cquery2 = $this->db->query("SELECT * FROM `fp_compare_products` WHERE cid='$pid'");
    $row2= $cquery2->num_rows();
    if($row1>0 || $row2>0){
        $data['compare_flag'] = 1;
        if($row1>0){
            $query = $this->db->query("SELECT * FROM fp_compare_products WHERE pid='$pid' limit 0,1");
            $prow=$query->row();
            $data['cid'] = $prow->cid;
            $data['pid'] = $pid;
        }
        if($row2>0){
            $query = $this->db->query("SELECT * FROM fp_compare_products WHERE cid='$pid' limit 0,1");
            $prow=$query->row();
            $data['cid'] = $prow->pid;
            $data['pid'] = $pid;
        }
    }
    //print_r($result_data);die;
    $variants=@$result_data[0]->variants;
    $str="";
        $vArr = explode("_",$variants);
        for($j=0;$j<count($vArr);$j++){
          if($j!=(count($vArr)-1)){
            $str.="v".@$vArr[$j]."=".@$valArr[$j]."&";
          }else{
            $str.="v".@$vArr[$j]."=".@$valArr[$j];
          }
        }
    $i=0;
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid'");
    $krows= $query->result();
    $vvalArr = array(); 
    foreach($krows as $kkey=>$kval){
      $vvalArr[] = explode("_",ltrim(rtrim($kval->variants_val,"_"),"_"));
    }

   $vvalsArr = array(); 
    foreach($vvalArr as $key=>$val){
      for($i=0;$i<count($val);$i++){
        if(!in_array($val[$i],$vvalsArr)){
          array_push($vvalsArr,$val[$i]);
        }
      }
    }
   $vins = "'".str_replace(",","','",implode(",",$vvalsArr))."'"; 
   //echo'<pre>';print_r($vins);die;
$i=0;   
foreach($result_data as $value) {
                      //echo $varint_id=$value->variants;
                      $ins = "'".str_replace("_","','",$value->variants)."'";
                      $result_data[$i]->VairantName = $this->getVairantName($ins,$value->pid,$vins,$str,$valArr);
                      $i++;
    }
   //die;
   
   $spacification=array();
   $query = $this->db->query("SELECT * FROM `fp_product_addinfo` WHERE pid='$pid'");
   $spacification= $query->result();
   $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Product data details','status'=>1,'spacification'=>$spacification,'compare_data'=>$data,'Product_data'=>$result_data);
          $this->response($msg); 
          }else{
           $msg=array('msg'=>'Product data Not found','status'=>0,'Product_data'=>'');
           $this->response($msg);  
          } 
     }   
}
public function getVairantName($ins,$rid,$vins,$str,$valArr){
     //print_r($valArr);die;
    $query = $this->db->query("SELECT * FROM `fp_variant` WHERE id IN($ins) ORDER BY name");
    $varint_name= $query->result();
    $j=0;  
foreach ($varint_name as $nkey=>$nval) {
              //echo $nval->name;die;
              
              $pos = strpos(strtolower($nval->name), 'color');
              $flag=0;
              if($pos!==false){  
                 $flag=1;
                }
               $varint_name[$j]->variants_val=$this->getVairantValName($vins,$nval->id,$rid,$flag,$str,$valArr);
               $j++;   
             }
     return $varint_name;
  }


public function getVairantValName($ins,$nval,$rid,$flag,$str,$valArr){
   $query = $this->db->query("SELECT id,vid,vname FROM `fp_variant_val` WHERE id IN($ins)");
   //echo $this->db->last_query();die;
    $vvnrows=$query->result();
    //echo $flag;
   //print_r($valArr);die;
     if($flag){
      $kk=array();
       foreach ($vvnrows as $key=>$val){
              if($val->vid==$nval){
                  
                     $throw = $this->getVairantDpath($rid,"_".$val->id."_");
                     //print_r($throw);
                       //echo $throw['dpath'];
                      //array_push($kk,$throw['id']);
                      
                       
                      if($throw['dpath']!=''){
                           if(in_array($val->id,$valArr)){
                            $selcted_class='@pcolor';
                            //$selected_id=$val->id;
                       	   }else{
                       	     $selcted_class='';  
                       	    }
                            array_push($kk,$throw['dpath'].'|'.$rid.'?p'.$nval.'='.$val->id.'&'.$str.$selcted_class);
                           }
                     
                    
                  }
                  
           }
          
       return $kk;
           }else{
           $ss=array();
           foreach ($vvnrows as $key=>$val){
                if($val->vid==$nval){
                    if(in_array($val->id,$valArr)){
                        //echo $val->id;
                           $selcted_class='@pcolor';
                            //$selected_id=$val->id;
                       	   }else{
                       	     $selcted_class='';  
                       	   }
                   array_push($ss, $val->vname.'|'.$rid.'?p'.$nval.'='.$val->id.'&'.$str.$selcted_class);
                  //return $val;
                 }
           }
           
     return $ss;

         }  


}
public function getVairantDpath($pid,$likeval){
   // echo "SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'".'<br>';
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
    //echo $this->db->last_query();
    return $query->row_array();
  }

}

