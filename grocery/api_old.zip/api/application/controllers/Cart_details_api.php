<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Cart_details_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
    $this->load->model('Checkout_model');
  }
  function index_get() { 



        //$cartItem=array(array('id'=>29,'kid'=>115,'product_name'=>'JBL T450 Wired Headphone','price'=>500,'path'=>'vupload/product/p_240_091020092719.jpg'),array('id'=>14,'kid'=>77,'product_name'=>'Redmi 9 A','price'=>500,'path'=>'image_path'));
        // print_r($cartItem);die;
        //$user_id=$_GET['userid'];
        $cartItem=@$_GET['cartArray'];
        //print_r($cartItem);die;
        $i=0;
        foreach($cartItem as $val){
           // print_r($val);die;
            $pid=$val['id']; 
            // $query = $this->db->query("SELECT v.name,l.variant_val FROM `fp_product_variant` as l INNER JOIN fp_variant as v ON l.variant=v.id WHERE l.pid='$pid'");
            // $vrows= $query->result_array();   
            $offRow=array();
            if($this->Checkout_model->checkDataById('fp_special_offer',array('pid'=>$val['id'],'pvs_id'=>$val['kid'],'status'=>'2'))>0){
              $offRow = $this->Checkout_model->getSignleRow('fp_special_offer',array('pid'=>$val['id'],'pvs_id'=>$val['kid'],'status'=>'2')); 
            } 
           $sprow = array();
           if($this->Checkout_model->countOffer(date('Y-m-d H:i:s'),$val['id'],$val['kid'])>0){
              $sprow = $this->Checkout_model->OfferRow(date('Y-m-d H:i:s'),$val['id'],$val['kid']);
            } 
           $prow = $this->Checkout_model->getSignleRow('fp_products',array('id'=>$val['id']));
           $vins = "'".str_replace("_","','",$prow->variants)."'";
           $skurow = $this->Checkout_model->getSignleRow('fp_product_variant_sku',array('id'=>$val['kid']));
           $lins = "'".str_replace("_","','",ltrim(rtrim($skurow->variants_val,"_"),"_"))."'";
            
           $vrows = $this->Checkout_model->cartVariantNames($vins,$lins);
          
        //   $wish_flag = 0;
        //   if($this->Checkout_model->checkDataById('fp_wishlist',array('pid'=>$val['id'],'kid'=>$val['kid'],'customer_id'=>$val['user_id']))>0){
        //       $wish_flag = 1;
        //     }
        if(!empty($vrows)){

          foreach($vrows as $vkey=>$vval){
                 
                 $cartItem[$i][$vval->name]=$vval->vname;

                }         
            }
        if(!empty($offRow)){

             $val[$i]['offer']= str_replace(".00","",$offRow->offer_amt);
             

           }    

       

        $i++;}
        
        //print_r($cartItem);
     //$cartItem[]=$val;
     $data_cnt=count($cartItem);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Cart product details','status'=>1,'Cart_data'=>$cartItem);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Cart data Not found','status'=>0,'Cart_data'=>'');
          $this->response($msg); 
          echo json_encode($msg);
          } 
    }

}


