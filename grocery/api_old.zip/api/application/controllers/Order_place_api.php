<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Order_place_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
    $this->load->model('Checkout_model');
	}
	function index_get() { 
      
       $cartArray=$_GET['cartArray'];
       //print_r($cartArray);die;
       $user_id=$_GET['user_id'];
      $address_id=$_GET['address_id'];
      //$bank_id=$_GET['bank_id']; 
      $bank_id=3;
      if($this->Checkout_model->checkTableData('fp_order')<=0){
      $orderid = ORDER_NO;
      }else{
      $row = $this->Checkout_model->LastOrderId();
      $orderid = ($row['orderid']+ORDER_INCREMENT);
      } 
     $dataArr = array('orderid'=>$orderid,'customer_id'=>$user_id,'payby'=>$bank_id,'customer_address_id'=>$address_id,'order_dt_tm'=>date('Y-m-d H:i:s'));
     if($this->db->insert('fp_order',$dataArr)){
      $order_tid = $this->db->insert_id();
      for($i=0;$i<count($cartArray);$i++){
           
        $cartArr = array('order_tid'=>$order_tid,'pid'=>$cartArray[$i]['pid'],'kid'=>$cartArray[$i]['id'],'qty'=>$cartArray[$i]['qty'],'price'=>$cartArray[$i]['price'],'discount'=>0,'create_by'=>$user_id,'create_dt_tm'=>date('Y-m-d H:i:s'));
        $this->db->insert('fp_order_detail',$cartArr);
         }
    //   foreach($cartArray as $key=>$val){
    //     $cartArr = array('order_tid'=>$order_tid,'pid'=>$val['id'],'kid'=>$val['kid'],'qty'=>$val['qty'],'price'=>$val['price'],'discount'=>$val['discount'],'create_by'=>$this->session->userdata('users')['id'],'create_dt_tm'=>date('Y-m-d H:i:s'));
    //     $this->db->insert('fp_order_detail',$cartArr);
    //   }
      $msg=array('msg'=>'Your order has been processed','status'=>1,'order_data'=>$dataArr);
      $this->response($msg);
      }else{
      
        $msg=array('msg'=>'Sorry, your delivery order can not be processed.','status'=>0,'order_data'=>$cartArr);
       $this->response($msg);
      }



     
    }
}


