<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Brand_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
		$this->load->model('Checkout_model');
	}
	function index_get() { 

      $query = $this->db->query("SELECT b.id,b.name FROM `fp_brand` as b INNER JOIN fp_products as p ON b.id=p.brand WHERE p.status='1' GROUP BY p.brand ORDER BY b.name");
      $result_data= $query->result();
      $colorRow = array();
    $colorRows = $this->Checkout_model->getColorList('color'); 
    foreach($colorRows as $ckey=>$cval){
       if($this->Checkout_model->chkProductColor("_".$cval['id']."_")){ 
         $colorRow[] = array('id'=>$cval['id'],'vname'=>$cval['vname']);
        }
      } 
      $data= $colorRow;
      $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('msg'=>'Brand details','status'=>1,'brand_data'=>$result_data,'color_data'=>$data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Brand Details Not found','status'=>0,'brand_data'=>'','color_data'=>'');
           $this->response($msg);  
          } 
    //   //echo $this->db->last_query();
    // }
    }
}


