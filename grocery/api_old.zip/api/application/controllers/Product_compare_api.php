<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Product_compare_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
		 $this->load->model('Checkout_model');
	}
	function index_get() { 
    
        //echo'<pre>';print_r($_GET);die;
     $pid= $_GET['pid'];
     $kid= $_GET['kid'];
    //$pid=5;
    //$kid=66;
    //$pid = encryptor('decrypt', $this->uri->segment(3));
    //$kid = encryptor('decrypt', $this->uri->segment(4));
    //$pid=$_GET['product_id'];
    // $kid=$_GET['id'];
     $query = $this->db->query("SELECT * FROM `fp_product_addinfo` WHERE pid='$pid'");
     $addinfo= $query->result();
     $data['spacification']=$addinfo;
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid'");
    $krows= $query->result();
    $variants_val=@$krows[0]->variants_val;
    //echo'<pre>';print_r($krows);
    // $vvalArr = array(); 
    // foreach($krows as $kkey=>$kval){
    //   $vvalArr[] = explode("_",ltrim(rtrim($kval->variants_val,"_"),"_"));
    // }
    // $variants_val=$_GET['variants_val'];
    $valArr = explode("_",ltrim(rtrim($variants_val,"_"),"_"));
    $this->db->select("fp_products.*,fp_product_variant_sku.id as id,fp_product_variant_sku.pid,fp_product_variant_sku.price,fp_product_variant_sku.dpath,fp_product_desc.highlight,fp_product_desc.content");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
    $this->db->join('fp_product_desc','fp_product_desc.pid=fp_products.id');
    $this->db->where('fp_products.id',$pid);
    $this->db->where('fp_product_variant_sku.id',$kid);
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
   //echo $this->db->last_query();die;
    $result_data=$query->result();
    //print_r($result_data);die;
    $variants=@$result_data[0]->variants;
    $str="";
        $vArr = explode("_",$variants);
        for($j=0;$j<count($vArr);$j++){
          if($j!=(count($vArr)-1)){
            $str.="v".@$vArr[$j]."=".@$valArr[$j]."&";
          }else{
            $str.="v".@$vArr[$j]."=".@$valArr[$j];
          }
        }
    $i=0;
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid'");
    $krows= $query->result();
    $vvalArr = array(); 
    foreach($krows as $kkey=>$kval){
      $vvalArr[] = explode("_",ltrim(rtrim($kval->variants_val,"_"),"_"));
    }

   $vvalsArr = array(); 
    foreach($vvalArr as $key=>$val){
      for($i=0;$i<count($val);$i++){
        if(!in_array($val[$i],$vvalsArr)){
          array_push($vvalsArr,$val[$i]);
        }
      }
    }
$vins = "'".str_replace(",","','",implode(",",$vvalsArr))."'"; 
  // echo'<pre>';print_r($vins);die;
$i=0;   
foreach($result_data as $value) {
                      //echo $varint_id=$value->variants;
                      $ins = "'".str_replace("_","','",$value->variants)."'";
                      $result_data[$i]->VairantName = $this->getVairantName($ins,$value->pid,$vins,$str,$valArr);
                      $i++;
    }
   $purl=$result_data[0]->purl;
   //$link=site_url($purl.'/'.encryptor('encrypt', $pid.'_'.$kid)).'?'.$str; 
   $link=$str; 
   $data['link']=$link; 
   $data['product_data']=$result_data;
   //echo json_encode($data);
   $data_cnt=count($data);
     if($data_cnt>0){
          //print_r($service_data);
          $msg=array('msg'=>'Product details','status'=>1,'compare_data'=>$data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Product Details Not found','status'=>0,'installment_details'=>'');
           $this->response($msg);  
          }
       }


public function getVairantName($ins,$rid,$vins,$str,$valArr){

    //print_r($vvalArr);die;
    $query = $this->db->query("SELECT * FROM `fp_variant` WHERE id IN($ins) ORDER BY name");
    $varint_name= $query->result();
    $j=0;  
foreach ($varint_name as $nkey=>$nval) {
              //echo $nval->name;die;
              //echo $nval->id;
              $pos = strpos(strtolower($nval->name), 'color');
              $flag=0;
              if($pos!==false){  
              $flag=1;
              }
             $varint_name[$j]->variants_val=$this->getVairantValName($vins,$nval->id,$rid,$flag,$str,$valArr);

             $j++;   
             }
     return $varint_name;
  }


public function getVairantValName($ins,$nval,$rid,$flag,$str,$valArr){
   $query = $this->db->query("SELECT id,vid,vname FROM `fp_variant_val` WHERE id IN($ins)");
   //echo $this->db->last_query();die;
    $vvnrows=$query->result();
    //echo $flag;
   //print_r($vvnrows);die;
     if($flag){
      $kk=array();
       foreach ($vvnrows as $key=>$val){
               //echo $nval;
               if($val->vid==$nval){
                
                     $throw = $this->getVairantDpath($rid,"_".$val->id."_");
                     //print_r($throw);
                       //echo $throw['dpath'];
                      //array_push($kk,$throw['id']);
                      if($throw['dpath']!=''){
                        if(in_array($val->id,$valArr)){
                           $selcted_class='pcolor';
                           }
                        array_push($kk,$throw['dpath']);
                       }
                     
                    
                  }
                  
           }
       return $kk;
           }else{
           $ss=array();
           foreach ($vvnrows as $key=>$val){
                if($val->vid==$nval){
                  if(in_array($val->id,$valArr)){
                           $selcted_class='pcolor';
                           }
                   array_push($ss, $val->vname);
                  //return $val;
                 }
           }
     return $ss;

         }  


}
public function getVairantDpath($pid,$likeval){
   // echo "SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'".'<br>';
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
    //echo $this->db->last_query();
    return $query->row_array();
  } 



}


