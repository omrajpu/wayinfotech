<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Subcategoery_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
	}
	function index_get() { 

      $catid=$_GET['cat_id'];  
      $this->db->select("*");
      $this->db->from('fp_childcategory');
      $this->db->where('fp_childcategory.catid',$catid);
      $this->db->order_by('id','desc');
      $query=$this->db->get();
      //echo $this->db->last_query();die;
      $result_data=$query->result();
      $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('msg'=>'Sub Categoery details','status'=>1,'sub_cat_data'=>$result_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Sub Categoery Details Not found','status'=>0,'sub_cat_data'=>'');
           $this->response($msg);  
          } 
    //   //echo $this->db->last_query();
    // }
    }
}


