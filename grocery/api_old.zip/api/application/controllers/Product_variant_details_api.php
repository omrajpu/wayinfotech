<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Product_variant_details_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_get() { 
      //$str='p49=40&v47=26&v48=33&v49=41';
      //$str='p49=41&v47=26&v48=33&v49=40';
      //$str="'".$_GET['vid']."'";
      
     
      $pid=$_GET['product_id'];
      $ar=explode('&',$_GET['vid']);
      $sk=array();
      foreach($ar as $key=>$val){
          $ary=explode('=',$val);
          $sk[$ary[0]]=$ary[1];
      }
    //print_r($sk);die;
     
    $this->db->select("*");
    $this->db->from('fp_products');
    $this->db->where('fp_products.id',$pid);
    $query=$this->db->get();
    $result_data=$query->row();
    $vArr = explode("_",$result_data->variants);
   // print_r($vArr);die;
    $cnt=count($vArr);
    $strArr=array(); $str="";
    for($i=0;$i<$cnt;$i++){
   //echo @$sk['p'.$vArr[$i]];
        
      if(!empty(@$sk['p'.$vArr[$i]])){
        $strArr[] = @$sk['p'.$vArr[$i]];
        $str.="&v".$vArr[$i]."=".@$sk['p'.$vArr[$i]];
        $pvid = @$sk['p'.$vArr[$i]];
      }else{
        $strArr[] =@$sk['v'.$vArr[$i]];
        $str.="&v".$vArr[$i]."=".@$sk['v'.$vArr[$i]];
      } 
    }
  
 //$pvid;
   $likeval= "_".implode("_",$strArr)."_";

   
   //echo "SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'";
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
     $row=$query->num_rows();
     if($row>0){
       $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
       $pvs_row=$query->row();
       $kid=$pvs_row->id;
       $variants_val=$pvs_row->variants_val;
       $this->get_product_details($pid,$kid,$variants_val);

     }else{


     }

  }
  
function get_product_details($pid,$kid,$variants_val){
    $valArr = explode("_",ltrim(rtrim($variants_val,"_"),"_"));
    $this->db->select("*");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
     $this->db->join('fp_product_desc','fp_product_desc.pid=fp_products.id');
    $this->db->where('fp_products.id',$pid);
    $this->db->where('fp_product_variant_sku.id',$kid);
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
    $result_data=$query->result();
    $variants=$result_data[0]->variants;
    $str="";
        $vArr = explode("_",$variants);
        for($j=0;$j<count($vArr);$j++){
          if($j!=(count($vArr)-1)){
            $str.="v".@$vArr[$j]."=".@$valArr[$j]."&";
          }else{
            $str.="v".@$vArr[$j]."=".@$valArr[$j];
          }
        }
    $i=0;
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid'");
    $krows= $query->result();
    $vvalArr = array(); 
    foreach($krows as $kkey=>$kval){
      $vvalArr[] = explode("_",ltrim(rtrim($kval->variants_val,"_"),"_"));
    }

   $vvalsArr = array(); 
    foreach($vvalArr as $key=>$val){
      for($i=0;$i<count($val);$i++){
        if(!in_array($val[$i],$vvalsArr)){
          array_push($vvalsArr,$val[$i]);
        }
      }
    }
   $vins = "'".str_replace(",","','",implode(",",$vvalsArr))."'"; 
  // echo'<pre>';print_r($vins);die;
$i=0;   
foreach($result_data as $value) {
                      //echo $varint_id=$value->variants;
                      $ins = "'".str_replace("_","','",$value->variants)."'";
                      $result_data[$i]->VairantName = $this->getVairantName($ins,$value->pid,$vins,$str);
                      $i++;
    }
   //die;
   $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Product data details','status'=>1,'Product_data'=>$result_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Product data Not found','status'=>0,'Product_data'=>'');
           $this->response($msg);  
          } 
    }  
  
public function getVairantName($ins,$rid,$vins,$str){

    //print_r($vvalArr);die;
    $query = $this->db->query("SELECT * FROM `fp_variant` WHERE id IN($ins) ORDER BY name");
    $varint_name= $query->result();
    $j=0;  
foreach ($varint_name as $nkey=>$nval) {
              //echo $nval->name;die;
              //echo $nval->id;
              $pos = strpos(strtolower($nval->name), 'color');
              $flag=0;
              if($pos!==false){  
              $flag=1;
              }
             $varint_name[$j]->variants_val=$this->getVairantValName($vins,$nval->id,$rid,$flag,$str);

             $j++;   
             }
     return $varint_name;
  }
 public function getVairantValName($ins,$nval,$rid,$flag,$str){
   $query = $this->db->query("SELECT id,vid,vname FROM `fp_variant_val` WHERE id IN($ins)");
   //echo $this->db->last_query();die;
    $vvnrows=$query->result();
    //echo $flag;
   //print_r($vvnrows);die;
     if($flag){
      $kk=array();
       foreach ($vvnrows as $key=>$val){
               //echo $nval;
               if($val->vid==$nval){
                
                     $throw = $this->getVairantDpath($rid,"_".$val->id."_");
                     //print_r($throw);
                       //echo $throw['dpath'];
                      //array_push($kk,$throw['id']);
                      if($throw['dpath']!=''){
                        array_push($kk,$throw['dpath'].'|'.$rid.'?p'.$nval.'='.$val->id.'&'.$str);
                       }
                     
                    
                  }
                  
           }
       return $kk;
           }else{
           $ss=array();
           foreach ($vvnrows as $key=>$val){
                if($val->vid==$nval){
                   array_push($ss, $val->vname.'|'.$rid.'?p'.$nval.'='.$val->id.'&'.$str);
                  //return $val;
                 }
           }
     return $ss;

         }  
  }

public function getVairantDpath($pid,$likeval){
   // echo "SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'".'<br>';
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
    //echo $this->db->last_query();
    return $query->row_array();
  }




  
  
  
  
}

