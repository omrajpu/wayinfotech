<?php
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Regenrate_pass_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->model('Checkout_model');
    $this->load->database();
  }
  function index_post(){ 
             
          $active_code=$_POST['active_code'];
          $user_id=$_POST['user_id'];
          $new_pass=md5(@$_POST['new_pass']);
         //$active_code='56fd5edb1c62eb89d62b15b96d1ce5ff';
         //$user_id=21;
         //$new_pass=md5(@$_POST['new_pass']);
          //print_r($_POST);
         //die;
         $res= $this->Checkout_model->check_user_email_activecode_exist($user_id,$active_code);
         //print_r($res);die;
         if(@$res->active_code){
            //echo"fgfh";die;
             $postdata = array(
                              'password' =>$new_pass,
                              'active_code'=>''
                             );

                    $this->Checkout_model->update_password($user_id,$postdata);
                    $msg=array('msg'=>'Your Password has been changed successfully','status'=>1);
                  $this->response($msg);
             
         }else{
            $msg=array('msg'=>'Your password recovery link expire','status'=>0);
            $this->response($msg);
           }
      
                    
  }
  
  
  
}