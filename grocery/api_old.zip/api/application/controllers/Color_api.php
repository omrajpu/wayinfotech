<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Color_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
    $this->load->model('Checkout_model');
	}
	function index_get() { 
    $colorRow = array();
    $colorRows = $this->Checkout_model->getColorList('color'); 
    foreach($colorRows as $ckey=>$cval){
       if($this->Checkout_model->chkProductColor("_".$cval['id']."_")){ 
         $colorRow[] = array('id'=>$cval['id'],'vname'=>$cval['vname']);
        }
      } 
     $data= $colorRow;
     $data_cnt=count($data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('msg'=>'Color details','status'=>1,'color_data'=>$data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Color Details Not found','status'=>0,'color_data'=>'');
           $this->response($msg);  
          } 
    //   //echo $this->db->last_query();
    // }
    }
}


