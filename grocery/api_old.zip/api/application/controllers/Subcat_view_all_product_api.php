<?php
//echo APPPATH;

header('Access-Control-Allow-Origin: *'); 
require APPPATH . '/libraries/REST_Controller.php';
class Subcat_view_all_product_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_post() { 
     if(@$_POST['discount']){
      $where = $this->get_discountdataTables();
      $querys = "SELECT c.id,c.offer_amt,p.id as pid,p.catid,p.subid,p.child_id,p.product_name,p.purl,p.variants,k.id as kid,k.price,k.avail_qty,k.dpath,k.variants_val FROM `fp_special_offer` as c INNER JOIN fp_products as p ON c.pid=p.id INNER JOIN fp_product_variant_sku as k ON k.pid=p.id ";
      $querys.= $where;
      // $querys.= " limit $start,$limit";
      //echo $querys;die;
       $query = $this->db->query($querys);
       $discount_all_data=$query->result();
       $msg=array('msg'=>'Discount all product data','status'=>1,'subcategoery_all_product_data'=>$discount_all_data);
      $this->response($msg);
    }else{ 
    $search_keyword=@$_POST['search_keyword'];
    if($search_keyword){
     $this->db->select("*");
     $this->db->from('fp_products');
     $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
     $this->db->like('fp_products.product_name', $search_keyword);
      $this->db->group_by('fp_product_variant_sku.pid');
    //$this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
    $view_all_product=$query->result();
    //echo $this->db->last_query();
   // print_r($view_all_product);
    $msg=array('msg'=>'Child sub categoery product details','status'=>1,'subcategoery_all_product_data'=>$view_all_product);
    $this->response($msg); 

    }else{
    $catid=@$_POST['cat_id'];
    if($catid){
    $sub_cat_id=@$_POST['sub_cat_id'];
    $child_id=@$_POST['child_id'];
    $this->db->select("*");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
    //$this->db->order_by('tbl_category.id','desc');
    $this->db->where('fp_products.catid',$catid);
    $this->db->where('fp_products.subid',$sub_cat_id);
    $this->db->where('fp_products.child_id',$child_id);
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
    $view_all_product=$query->result();
   // print_r($view_all_product);
    $msg=array('msg'=>'Child sub categoery product details','status'=>1,'subcategoery_all_product_data'=>$view_all_product);
      $this->response($msg); 
     }
   else{
       
        $Where = " WHERE (p.status='1') ";
      if(@$_POST['brand']){
      $Where.= " AND p.brand=".@$_POST['brand'];
    }
    if(@$_POST['[minPrice] ']){
      $Where.= " AND k.price>=".@$_POST['[minPrice] '];
    }
    if(@$_POST['[maxPrice] ']){
      $Where.= " AND k.price<=".@$_POST['[maxPrice] '];
    }
    if(@$_POST['color']){
      $Where.= " AND k.variants_val like '%_".@$_POST['color']."_%'";
    }
    
    $groupby = " GROUP BY p.id ";
        $querys = "SELECT k.id,c.name,c.curl,c.is_home,p.id as pid,p.catid,p.subid,p.child_id,p.product_name,p.purl,p.variants,k.id as kid,k.price,k.avail_qty,k.dpath,k.variants_val FROM `fp_category` as c INNER JOIN fp_products as p ON c.id=p.catid INNER JOIN fp_product_variant_sku as k ON k.pid=p.id ";
    $querys.= $Where;
  
    //echo $querys;
      $query = $this->db->query($querys);
      $view_all_product=$query->result();
       
       
    // $view_all_product=array();
       $msg=array('msg'=>'Child sub categoery product details','status'=>1,'subcategoery_all_product_data'=>$view_all_product);
       $this->response($msg);
         }
       }
     }
  }
public function get_discountdataTables(){
    $Where = " WHERE (c.status='2' AND p.status='1') ";
      if($this->input->post("brand")){
      $Where.= " AND p.brand=".$this->input->post("brand");
    }
    if($this->input->post("min")){
      $Where.= " AND k.price>=".$this->input->post("min");
    }
    if($this->input->post("max")){
      $Where.= " AND k.price<=".$this->input->post("max");
    }
    if($this->input->post("color")){
      $Where.= " AND k.variants_val like '%_".$this->input->post("color")."_%'";
    }
      $groupby = " GROUP BY p.id ";
      $orderby = " ORDER BY p.id ";
      if($this->input->post("sort")=="price_asc"){
      $orderby= " ORDER BY k.price ASC ";
    }
    if($this->input->post("sort")=="price_desc"){
      $orderby= " ORDER BY k.price DESC ";
    }
    if($this->input->post("sort")=="new"){
      $orderby= " ORDER BY p.id DESC ";
    }
    
    return $Where.$groupby.$orderby;
  }
  
}


