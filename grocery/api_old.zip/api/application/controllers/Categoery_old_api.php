<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Categoery_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
	}
	function index_get() { 

         
      $this->db->select("*");
      $this->db->from('fp_category');
      $this->db->order_by('id','desc');
      $query=$this->db->get();
      $result_data=$query->result();
       // return $res;
       //echo '<pre>';print_r($result_data);
       //$result_data2=array((object)array('test'=>'fgglhk','id'=>22));
       //echo '<pre>';print_r($result_data2);die;

    $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Product photo details','status'=>1,'Categoery_data'=>$result_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Ctaegoery Details Not found','status'=>0,'Categoery_data'=>'');
           $this->response($msg);  
          } 
    //   //echo $this->db->last_query();
    // }
    }
}


