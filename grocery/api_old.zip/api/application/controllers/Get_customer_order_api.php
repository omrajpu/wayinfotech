<?php
//echo APPPATH;

header('Access-Control-Allow-Origin: *'); 
require APPPATH . '/libraries/REST_Controller.php';
class Get_customer_order_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_get() { 
       //echo'hi';
      //print_r($_GET);die;

     $customer_id=@$_GET['user_id'];
    //$customer_id=32;
    if(@$customer_id){
     $query = $this->db->query("SELECT d.*,r.orderid,r.customer_id,r.customer_address_id,r.status,r.order_dt_tm FROM `fp_order_detail` as d INNER JOIN fp_order as r ON d.order_tid=r.id WHERE d.create_by='$customer_id' ORDER BY d.id DESC");
     $rows=$query->result();
     $i=0;
     foreach($rows as $val){
     $rows[$i]->product_data = $this->cartData($val->pid,$val->kid);
     $rows[$i]->address_data= $this->address_data($val->customer_address_id);
     $rows[$i]->rating_data= $this->rating_data($customer_id,$val->pid);
     $i++; }
    // print_r($view_all_product);
     $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Customer order details','status'=>1,'customer_order_data'=>$rows);
     $this->response($msg); 
    }
   else{
    $view_all_product=array();
    $msg=array('msg'=>'Customer order details','status'=>0,'customer_order_data'=>$view_all_product);
    $this->response($msg);
    }

 }
public function cartData($id,$kid){
    $query = $this->db->query("SELECT p.id,p.product_name,p.purl,p.variants,k.id as kid,k.price,k.dpath,k.variants_val FROM `fp_products` as p INNER JOIN fp_product_variant_sku as k ON p.id=k.pid WHERE p.id='$id' AND k.id='$kid' ");
    return $query->result();
  }
public function address_data($customer_address_id){
    $query = $this->db->query("SELECT * FROM `fp_customer_address`  WHERE id='$customer_address_id'");
    return $query->row();
  }
 public function rating_data($customer_id,$pid){
    $query = $this->db->query("SELECT * FROM `fp_rating_review`  WHERE userid='$customer_id' and pid='$pid'");
    return $query->row();
  }
  
}


