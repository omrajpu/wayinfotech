<?php
//echo APPPATH;

header('Access-Control-Allow-Origin: *'); 
require APPPATH . '/libraries/REST_Controller.php';
class Categoery_subcat_wise_product_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_POST() { 

       $catid=@$_POST['cat_id'];
       $sub_child_id=@$_POST['sub_child_id'];
       //$sub_child_id=13;
       if(@$catid){
       $this->db->select("id as child_id,name,subid");
       $this->db->where('fp_childcategory.catid',$catid);
       $this->db->group_by('fp_childcategory.name');
       $this->db->from("fp_childcategory");
       $query=$this->db->get();
          //echo $this->db->last_query();die;
       $result=$query->result();
        $result_data=array();
        $i=0;
       foreach ($result as $value) {
        //print_r($value->name);
         $result[$i]->child_product=$this->get_subcat_product($catid,$value->subid,$value->child_id);
          $i++;
          }
      }else{
       $this->db->select("id as child_id,name,catid,subid");
       $this->db->where('fp_childcategory.id',$sub_child_id);
       $this->db->from("fp_childcategory");
       $query=$this->db->get();
        //echo $this->db->last_query();die;
        $result=$query->result();
       
      // print_r($result);die;
       $result_data=array();
       $i=0;
       foreach ($result as $value) {
        //print_r($value->name);
         $result[$i]->child_product=$this->get_subcat_product($value->catid,$value->subid,$value->child_id);
            //$result_data[]=$p_image;
          $i++;      
       }
     }  
  $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'General categoery product details','status'=>1,'child_categoery_data'=>$result);
      $this->response($msg); 
   }
  public function get_subcat_product($catid,$sub_cat_id,$child_id){
    $this->db->select("*");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
    //$this->db->order_by('tbl_category.id','desc');
    $this->db->where('fp_products.catid',$catid);
    $this->db->where('fp_products.subid',$sub_cat_id);
    $this->db->where('fp_products.child_id',$child_id);
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
    $categories=$query->result();
    //echo $this->db->last_query();die;
    return $categories;
    
    } 
}


