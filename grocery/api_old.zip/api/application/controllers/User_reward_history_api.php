<?php
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class User_reward_history_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_get() { 
//echo 'test';
       $custid=$_GET['custid'];
     $querys = "SELECT year(order_dt_tm) AS order_year,order_dt_tm AS order_month,SUM(points) AS points, SUM(order_amount) AS orderamount FROM `fp_reward_transactions` WHERE customer_id='$custid' GROUP BY customer_id,year(order_dt_tm),month(order_dt_tm) ORDER BY year(order_dt_tm),month(order_dt_tm) ";

     
      $query = $this->db->query($querys);
      //echo $this->db->last_query();die;
      $result_data=$query->result_array();
     $data_cnt=count($result_data);
    if($data_cnt>0){
      
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin/qr_codes','msg'=>'User Reward details','status'=>1,'reward_history_data'=>$result_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'User Reward details Not found','status'=>0,'reward_data'=>'');
           $this->response($msg);  
          } 
    
  } 
}