<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Get_all_product_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_get() { 

    $this->db->select("fp_products.*,fp_product_variant_sku.id as id,fp_product_variant_sku.pid,fp_product_variant_sku.price,fp_product_variant_sku.dpath,fp_product_desc.highlight,fp_product_desc.content");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
    $this->db->join('fp_product_desc','fp_product_desc.pid=fp_products.id');
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
    $result_product_data=$query->result();
    $data['all_product_data']=$result_product_data;

    $data_cnt=count($result_product_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Product details','status'=>1,'product_data'=>$data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'product data Not found','status'=>0,'product_data'=>'');
           $this->response($msg);  
          } 
    //   //echo $this->db->last_query();
    // }
    }
   
}


