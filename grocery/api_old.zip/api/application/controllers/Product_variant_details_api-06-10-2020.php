<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Product_variant_details_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_get() { 
    
    //$pid=$_GET['product_id'];
     echo $pid=$_GET['product_id'];
    echo  $vid=$_GET['vid'];

     die;
    $this->db->select("*");
    $this->db->from('fp_products');
    $this->db->where('fp_products.id',$pid);
    $query=$this->db->get();
    $result_data=$query->row();
    $vArr = explode("_",$result_data->variants);
   // print_r($vArr);die;
    $strArr=array(); $str="";
    for($i=0;$i<count($vArr);$i++){
      if(!empty('p'.$vArr[$i])){
        $strArr[] = $this->input->get('p'.$vArr[$i]);
        $str.="&v".$vArr[$i]."=".$this->input->get('p'.$vArr[$i]);
        $pvid = $this->input->get('p'.$vArr[$i]);
      }else{
        $strArr[] ='v'.$vArr[$i];
        $str.="&v".$vArr[$i]."=".'v'.$vArr[$i];
      } 
    }
  
    $likeval= "_".implode("_",$strArr)."_";
    print_r($likeval);
die;


    $i=0;
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid'");
    $krows= $query->result();
    //$data['krows'] = $this->get_Rows('fp_product_variant_sku',array('pid'=>$data['row']['id']));
    $vvalArr = array(); 
    foreach($krows as $kkey=>$kval){
      $vvalArr[] = explode("_",ltrim(rtrim($kval->variants_val,"_"),"_"));
    }

   $vvalsArr = array(); 
    foreach($vvalArr as $key=>$val){
      for($i=0;$i<count($val);$i++){
        if(!in_array($val[$i],$vvalsArr)){
          array_push($vvalsArr,$val[$i]);
        }
      }
    }
   $vins = "'".str_replace(",","','",implode(",",$vvalsArr))."'"; 
  // echo'<pre>';print_r($vins);die;
$i=0;   
foreach($result_data as $value) {
                      //echo $varint_id=$value->variants;
                      $ins = "'".str_replace("_","','",$value->variants)."'";
                      $result_data[$i]->VairantName = $this->getVairantName($ins,$value->pid,$vins);
                      $i++;
    }
   //die;
   $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Product data details','status'=>1,'Product_data'=>$result_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Product data Not found','status'=>0,'Product_data'=>'');
           $this->response($msg);  
          } 
        }

public function getVairantName($ins,$rid,$vins){

    //print_r($vvalArr);die;
    $query = $this->db->query("SELECT * FROM `fp_variant` WHERE id IN($ins) ORDER BY name");
    $varint_name= $query->result();
    $j=0;  
foreach ($varint_name as $nkey=>$nval) {
              //echo $nval->name;die;
              //echo $nval->id;
              $pos = strpos(strtolower($nval->name), 'color');
              $flag=0;
              if($pos!==false){  
              $flag=1;
              }
             $varint_name[$j]->variants_val=$this->getVairantValName($vins,$nval->id,$rid,$flag);

             $j++;   
             }
     return $varint_name;
  }


public function getVairantValName($ins,$nval,$rid,$flag){
   $query = $this->db->query("SELECT id,vid,vname FROM `fp_variant_val` WHERE id IN($ins)");
   //echo $this->db->last_query();die;
    $vvnrows=$query->result();
    //echo $flag;
   //print_r($vvnrows);die;
     if($flag){
      $kk=array();
       foreach ($vvnrows as $key=>$val){
               //echo $nval;
               if($val->vid==$nval){
                
                     $throw = $this->getVairantDpath($rid,"_".$val->id."_");
                     //print_r($throw);
                       //echo $throw['dpath'];
                      //array_push($kk,$throw['id']);
                      if($throw['dpath']!=''){
                        array_push($kk,$throw['dpath'].'|'.$val->id);
                       }
                     
                    
                  }
                  
           }
       return $kk;
           }else{
           $ss=array();
           foreach ($vvnrows as $key=>$val){
                if($val->vid==$nval){
                   array_push($ss, $val->vname.'|'.$val->id);
                  //return $val;
                 }
           }
     return $ss;

         }  


}
public function getVairantDpath($pid,$likeval){
   // echo "SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'".'<br>';
    $query = $this->db->query("SELECT * FROM `fp_product_variant_sku` WHERE pid='$pid' AND variants_val LIKE '%$likeval%'");
    //echo $this->db->last_query();
    return $query->row_array();
  }

}

