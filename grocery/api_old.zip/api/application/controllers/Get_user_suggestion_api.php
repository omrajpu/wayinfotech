<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Get_user_suggestion_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
		 $this->load->model('Checkout_model');
	}
	function index_get() { 
     $user_id=@$_GET['user_id'];
     if($user_id!=''){
           $user_id=$_GET['user_id'];
           $title=$_GET['title'];
           $description=$_GET['description'];
           $created_date=date('Y-m-d H:i:s');
           $insert_data=array(
                    'user_id'=>$user_id,
                    'title'=>$title,
                    'description'=>$description,
                    'created_date'=>$created_date
                   );
              // print_r($insert_data);die;
              $this->Checkout_model->save_suggestion_data($insert_data);
              $msg=array('msg'=>'Suggestion save successfully','status'=>1,'user_address'=>$insert_data);
                 $this->response($msg);
          }
	}
}
