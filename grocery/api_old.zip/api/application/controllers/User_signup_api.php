<?php
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class User_signup_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->model('Checkout_model');
    $this->load->database();
  }
  function index_post(){ 
              //$data = json_decode(file_get_contents('php://input'));
               // print_r($_POST);die;
               $type=@$_POST['type'];
               if($type=='facebook'){
                   $fname=@$_POST['fname'];
                   $lname=@$_POST['lname'];
                   $photo=@$_POST['picture'];
                   $email=@$_POST['email'];
                   $fb_user_id=$_POST['id'];
                    $check_reg_user = $this->Checkout_model->check_reg_fb_user($fb_user_id);
                      // print_r($check_reg_user);die;
                       if(@$check_reg_user->id!=''){
                           if(@$check_reg_user->mobile){
                           $user_mobile=@$check_reg_user->mobile;
                           }else{
                             $user_mobile='';  
                           }
                           if(@$check_reg_user->email){
                            $user_email=@$check_reg_user->email;
                           }else{
                             $user_email='';  
                           }
                           
                       $image=@$check_reg_user->photo;
                       $msg=array('msg'=>'You are successfully register','status'=>'1','fname'=>$fname,'lname'=>$lname,'fb_user_id'=>$fb_user_id,'type'=>'facebook','image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin/api/profile_pic/','image'=>$image,'user_mobile'=>$user_mobile,'user_email'=>$user_email);
                       $this->response($msg,200);
                       }else{
                       $created_date=date('Y-m-d H:i:s');
                       $insert_data=array(
                            'photo'=>$photo,
                            'email'=>$email,
                            'fname'=>$fname,
                            'lname'=>$lname,
                            'fb_user_id'=>$fb_user_id,
                            'type'=>'facebook',
                            'create_dt_tm'=>$created_date
                           );
                      // print_r($insert_data);die;
                      $this->Checkout_model->save_customer_data($insert_data);
                      $msg=array('msg'=>'You are successfully register','status'=>'1','fname'=>$fname,'lname'=>$lname,'fb_user_id'=>$fb_user_id,'type'=>'facebook','image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin/api/profile_pic/','image'=>'','user_mobile'=>'','user_email'=>'');
                      $this->response($msg,200);
                      }
               }else{
              $email=$_POST['email'];
              $mobile=$_POST['mobile'];
              $fname=$_POST['fname'];
              $lname=$_POST['lname'];
              $password= md5(@$_POST['password']);       
              $check_reg_user = $this->Checkout_model->check_reg_user($email);
               //print_r($check_reg_user);die;
               if(@$check_reg_user->id!=''){
                 $msg=array('msg'=>'You are already register by this email id!','status'=>'0','user_details'=>'');
                 $this->response($msg,200);
               }else{
               $created_date=date('Y-m-d H:i:s');
               $insert_data=array(
                    'fname'=>$fname,
                    'lname'=>$lname,
                    'email'=>$email,
                    'password'=>$password,
                    'mobile'=>$mobile,
                    'create_dt_tm'=>$created_date
                   );
              // print_r($insert_data);die;
              $this->Checkout_model->save_customer_data($insert_data);
              $msg=array('msg'=>'You are successfully register','status'=>'1','fname'=>$fname,'lname'=>$lname,'email'=>$email,'mobile'=>$mobile);
              $this->response($msg,200);
              }
              
            }  
                    
  }
  
  
  
}