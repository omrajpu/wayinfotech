<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Edit_user_address_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
		 $this->load->model('Checkout_model');
	}
	function index_get() { 

      //print_r($_GET);die;
       $address_edit_id=@$_GET['user_edit_id'];
     if($address_edit_id!=''){
           $user_id=$_GET['user_id'];
           $uname=$_GET['add_name'];
           $phone=$_GET['phone'];
           $pincode=$_GET['pincode'];
           $locality=$_GET['locality'];
           $address=$_GET['address'];
           $city=$_GET['city'];
           $address_type=$_GET['address_type'];
           $created_date=date('Y-m-d H:i:s');
           $landmark=$_GET['landmark'];
            $update_data=array(
                    'name'=>$uname,
                    'phone'=>$phone,
                    'pincode'=>$pincode,
                    'locality'=>$locality,
                     'address'=>$address,
                     'city'=>$city,
                      'landmark'=>$landmark, 
                      'type'=>$address_type,
                    'modify_dt_tm'=>$created_date
                   );
              // print_r($insert_data);die;
              $res=$this->Checkout_model->update_user_checkout_data($update_data,$address_edit_id,$user_id);
              
               //$user_id=32;  
              $this->db->select("*");
              $this->db->from('fp_customer_address');
              $this->db->where('fp_customer_address.custid',$user_id);
              $query=$this->db->get();
              //echo $this->db->last_query();die;
              $result_data=$query->result();
              $data_cnt=count($result_data);
              if($data_cnt>0){
                  $msg=array('msg'=>'Update successfully','status'=>1,'user_address'=>$result_data);
                 $this->response($msg);
              }else{
                 $msg=array('msg'=>'Update issue','status'=>0,'user_address'=>'');
                 $this->response($msg);   
              }
          
          
          
          
          
       }else{
           //print_r($_GET);die;
          $address_delete_id=@$_GET['user_delete_id'];
          $user_id=$_GET['user_id'];
          $res=$this->Checkout_model->delete_user_checkout_data($address_delete_id,$user_id);
               //$user_id=32;  
              $this->db->select("*");
              $this->db->from('fp_customer_address');
              $this->db->where('fp_customer_address.custid',$user_id);
              $query=$this->db->get();
              //echo $this->db->last_query();die;
              $result_data=$query->result();
              $data_cnt=count($result_data);
              if($data_cnt>0){
                  $msg=array('msg'=>'Delete successfully','status'=>1,'user_address'=>$result_data);
                 $this->response($msg);
              }else{
                 $msg=array('msg'=>'Delete successfully','status'=>1,'user_address'=>'');
                 $this->response($msg);   
              }
           
           
           
           
       }
    
    
    
    
  }

}
