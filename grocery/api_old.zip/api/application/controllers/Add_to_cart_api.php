<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Add_to_cart_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
    $this->load->model('Checkout_model'); 
	}
	function index_get() { 

      $pid=$_GET['pid'];
      $kid=$_GET['child_id']; 
      //$pid=5;
      //$kid=66;  
     // echo "SELECT p.id,p.product_name,k.id as kid,k.price,k.dpath FROM `fp_products` as p INNER JOIN fp_product_variant_sku as k ON p.id=k.pid WHERE p.id='$pid' AND k.id='$kid'" ;
       $query = $this->db->query("SELECT p.id,p.product_name,k.id as kid,k.price,k.dpath FROM `fp_products` as p INNER JOIN fp_product_variant_sku as k ON p.id=k.pid WHERE p.id='$pid' AND k.id='$kid' ");
    $row=$query->result();
//print_r($row);die;
    $discount = 0; $price = @$row[0]->price;
    if($this->Checkout_model->checkDataById('fp_special_offer',array('pid'=>@$row[0]->id,'pvs_id'=>@$row[0]->kid,'status'=>'2'))>0){

        $drow = $this->Checkout_model->getSignleRow('fp_special_offer',array('pid'=>@$row[0]->id,'pvs_id'=>@$row[0]->kid,'status'=>'2'));
       // $discount = $drow['offer_amt'];
       // print_r($drow);
        $discount = $drow->offer_amt;


        }
       $offer = 0;
       if($this->Checkout_model->countOffer(date('Y-m-d H:i:s'),$pid,$kid)>0){
        $frow = $this->Checkout_model->OfferRow(date('Y-m-d H:i:s'),$pid,$kid);
         $price = ($price-$frow->offer_amt);
        }
        $cartArr[] = array('id'=>@$row[0]->id,'kid'=>@$row[0]->kid,'qty'=>'1','price'=>$price,'product_name'=>@$row[0]->product_name,'path'=>@$row[0]->dpath,'discount'=>$discount);
        //print_r($cartArr);

      //echo $this->db->last_query();die;
      //$result_data=$query->result();
      $data_cnt=count($cartArr);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('msg'=>'Cart item details','status'=>1,'cart_item_data'=>$cartArr);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Cart item details not found','status'=>0,'cart_item_data'=>'');
           $this->response($msg);  
          } 
    //   //echo $this->db->last_query();
    // }
    }
}


