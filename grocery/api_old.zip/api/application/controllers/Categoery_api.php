<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Categoery_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->database();
  }
  function index_get() { 

       $this->db->select('*');
        $this->db->from('fp_category');
        $parent = $this->db->get();
        $categories = $parent->result();
        $i=0;
        foreach($categories as $p_cat){
            $categories[$i]->sub = $this->sub_categories($p_cat->id);
            $i++;
        }
        $this->db->select('*');
        $this->db->from('fp_banner');
        $parent2 = $this->db->get();
        $categories2 = $parent2->result();
        $banner_data=$categories2;
       $data_cnt=count($categories);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('image_path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','msg'=>'Product photo details','status'=>1,'Categoery_data'=>$categories,'banner_data'=>$banner_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Ctaegoery Details Not found','status'=>0,'Categoery_data'=>'');
          $this->response($msg); 
          //echo json_encode($msg);
          } 
   
   
    }
       
        //return $categories;
   
 // echo json_encode($categories);
 

  
public function sub_categories($cid){

        $this->db->select('*');
        $this->db->from('fp_subcategory');
        $this->db->where('catid', $cid);

        $child = $this->db->get();
        $categories = $child->result();
        $i=0;
        foreach($categories as $p_cat){

            $categories[$i]->child = $this->child_cat_data($cid,$p_cat->id);
            $i++;
        }
        //echo json_encode($categories); 
        return $categories;
    
    

} 
public function child_cat_data($catid,$sub_cat_id){
    $this->db->select("id as child_id,name");
    $this->db->from('fp_childcategory');
    //$this->db->group_by('fp_childcategory.name');
    $this->db->where('fp_childcategory.catid',$catid);
    $this->db->where('fp_childcategory.subid',$sub_cat_id);
    $query=$this->db->get();
    $categories=$query->result();
    $i=0;
   foreach($categories as $p_cat){

            $categories[$i]->child_product = $this->get_subcat_product($catid,$sub_cat_id,$p_cat->child_id);
            $i++;
        }
    // foreach($ress as $childcat){
    //       $return[$childcat->child_id] = $childcat;
    //       //$return[$childcat->child_id]->product_data = $this->get_subcat_product($catid,$sub_cat_id,$childcat->child_id);
    // }
    return $categories;
  }

 public function get_subcat_product($catid,$sub_cat_id,$child_id){
    $this->db->select("*");
    $this->db->from('fp_products');
    $this->db->join('fp_product_variant_sku','fp_product_variant_sku.pid=fp_products.id');
    //$this->db->order_by('tbl_category.id','desc');
    $this->db->where('fp_products.catid',$catid);
    $this->db->where('fp_products.subid',$sub_cat_id);
    $this->db->where('fp_products.child_id',$child_id);
    $this->db->group_by('fp_product_variant_sku.pid');
    $query=$this->db->get();
    $categories=$query->result();
    //echo $this->db->last_query();die;
    return $categories;
   
    } 


}


