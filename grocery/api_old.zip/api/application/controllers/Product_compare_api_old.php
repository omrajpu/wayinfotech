<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Product_compare_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
		 $this->load->model('Checkout_model');
	}
	function index_get() { 
	    
    //print_r($_GET);die;
      $pid=$_GET['pid'];
      $cid=$_GET['cid'];
     // $pid=8;
      //$cid=9;
     $cquery = $this->db->query("SELECT * FROM `fp_compare_products` WHERE pid='$pid' and cid='$cid'");
     $row1= $cquery->num_rows();
     if($row1>0){
      $query1 = $this->db->query("SELECT c.id,c.pid,c.cid,c.head_id,h.heading FROM `fp_compare_products` as c INNER JOIN fp_compare_heads as h ON c.head_id=h.id WHERE c.pid='$pid' AND c.cid='$cid'");
      $crows=$query1->result();
     }
     $cquery2 = $this->db->query("SELECT * FROM `fp_compare_products` WHERE cid='$pid' and cid='$pid'");
     $row2= $cquery2->num_rows();
     if($row2>0){
      $query2 = $this->db->query("SELECT c.id,c.pid,c.cid,c.head_id,h.heading FROM `fp_compare_products` as c INNER JOIN fp_compare_heads as h ON c.head_id=h.id WHERE c.pid='$cid' AND c.cid='$pid'");
      $crows=$query2->result();
     }
     foreach($crows as $ckey=>$cval){
               $compare_prod_tid=$cval->id;
               $crows_data=$this->get_pro_data($compare_prod_tid); 
              
     }
      $query = $this->db->query("SELECT p.*,k.id as kid,k.sku,k.price,k.dpath FROM fp_products as p INNER JOIN fp_product_variant_sku as k ON p.id=k.pid WHERE (p.status='1' AND p.id='$pid') GROUP BY p.id");
      $result_data_pid=$query->result();
      $query2 = $this->db->query("SELECT p.*,k.id as kid,k.sku,k.price,k.dpath FROM fp_products as p INNER JOIN fp_product_variant_sku as k ON p.id=k.pid WHERE (p.status='1' AND p.id='$cid') GROUP BY p.id");
      $result_data_cid=$query2->result();
      $data_cnt=count($result_data_pid);
        if($data_cnt>0){
          //print_r($service_data);
          $msg=array('msg'=>'Product details','status'=>1,'path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','product_data'=>$result_data_pid,'compare_data'=>$result_data_cid,'product_attribute_data'=>$crows_data);
          $this->response($msg); 
          }else{
           $msg=array('msg'=>'Product Details Not found','status'=>0,'installment_details'=>'');
           $this->response($msg);  
          } 
  
     }
function get_pro_data($compare_prod_tid){
         $cquery = $this->db->query("SELECT * FROM `fp_compare_feature` WHERE compare_prod_tid='$compare_prod_tid'");
         $crows_data= $cquery->result(); 
         return $crows_data;
      }     
     
}


