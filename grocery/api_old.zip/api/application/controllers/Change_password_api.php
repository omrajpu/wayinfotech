<?php
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Change_password_api extends REST_Controller {
  function __construct($config = 'rest') {
    parent::__construct($config);
    $this->load->model('Checkout_model');
    $this->load->database();
  }
  function index_get(){ 
             //$data = json_decode(file_get_contents('php://input'));
             //print_r($_GET);die;
             $user_id    =   $_GET['user_id'];
             $oldpass    =   md5($_GET['old_pass']);
             $newpass    =   $_GET['new_pass'];
             $renewpass  =   $_GET['conf_pass'];
             $do_match = $this->Checkout_model->check_user_exist($user_id,$oldpass);
            if($do_match>0){
              if($newpass == $renewpass)
                 {
                  $postdata = array(
                              'password' =>md5($newpass)
                             );
                    $this->Checkout_model->update_password($user_id,$postdata);
                    $msg=array('msg'=>'Your Password has changed successfully','status'=>'1');
                    $this->response($msg,200);
                }else{
                  $msg=array('msg'=>'Sorry Your New Password or Re-new Password not match','status'=>'0');
                    $this->response($msg,200);
                    }  

               }else{
                $msg=array('msg'=>'Sorry your old password does not match','status'=>'0');
                $this->response($msg,200);
               }

              
}
  
  
  
}