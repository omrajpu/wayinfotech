<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Add_to_wishlist_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
    $this->load->model('Checkout_model'); 
	}
	function index_get() { 

      $pid=$_GET['pid'];
      $kid=$_GET['child_id']; 
      $user_id=$_GET['user_id'];
      //$user_id=21;
      //$pid=5;
      //$kid=66;  
      if($this->Checkout_model->checkDataById('fp_products',array('id'=>$pid))>0){
         if($this->Checkout_model->checkDataById('fp_wishlist',array('pid'=>$pid,'kid'=>$kid,'customer_id'=>$user_id))>0){
           $msg=array('msg'=>'Item Already added to wishlist.','status'=>1);
           $this->response($msg);
            exit;
          }
          $dataArr = array('pid'=>$pid,'kid'=>$kid,'customer_id'=>$user_id,'create_dt_tm'=>date('Y-m-d H:i:s'));

        if($this->db->insert('fp_wishlist',$dataArr)){
           $ct = $this->Checkout_model->checkDataById('fp_wishlist',array('customer_id'=>$user_id));

           $msg=array('msg'=>'Item added to wishlist.','status'=>1,'item_data'=>$dataArr);
           $this->response($msg);
          }

       }
}

}
