<?php
//echo APPPATH;
header('Access-Control-Allow-Origin: *');
require APPPATH . '/libraries/REST_Controller.php';
class Get_installment_loan_api extends REST_Controller {
	function __construct($config = 'rest') {
		parent::__construct($config);
		$this->load->database();
		$this->load->model('Checkout_model');
	}
	function index_get() { 
  
      $this->db->select("*");
      $this->db->from('fp_installment');
      $query=$this->db->get();
      //echo $this->db->last_query();die;
      $result_data=$query->result();
      $data_cnt=count($result_data);
    if($data_cnt>0){
          //print_r($service_data);
          $msg=array('msg'=>'Installment details','path'=>'http://stage.wayinfotechsolutions.co/lugyimin_admin/','status'=>1,'installment_details'=>$result_data);
          $this->response($msg); 
          }else{
          $msg=array('msg'=>'Installment Details Not found','status'=>0,'installment_details'=>'');
          $this->response($msg);  
          } 
  
     }
}


